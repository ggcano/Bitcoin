//
//  ViewController.swift
//  pruebaAlamo
//
//  Created by user on 28/1/19.
//  Copyright © 2019 Adrian Cano. All rights reserved.
//

import UIKit
import Alamofire


class ViewController: UIViewController {

    @IBOutlet weak var priceLabel: UILabel!
	
    @IBOutlet weak var priceLabel2: UILabel!
    
    @IBOutlet weak var BotonRecarga: UIButton!
    
	static let kRATE = "rate_float"
	static let kUSD = "USD"
	static let kBPI = "bpi"
	
	
	static let kRATE2 = "rate_float"
	static let kEUR = "EUR"
	static let kBPI2 = "bpi"
	
	var rate: Double = 0.0
	var rate2: Double = 0.0
	
	let url = "https://api.coindesk.com/v1/bpi/currentprice.json"

    override func viewDidLoad() {
        super.viewDidLoad()
		
		BotonRecarga.layer.cornerRadius = 14
		
		
		//esto no sirve para nada, estoy probando un text en pantalla
        priceLabel.text = "..."
       
		
		Alamofire.request(url).responseJSON { response in
			let bitcoinJSON = response.result.value
			
                let bitcoinObject: Dictionary = bitcoinJSON as! Dictionary<String, Any>
			
			_ = bitcoinObject["code"]
        		print(bitcoinObject)
			
			//esta es la api
			// https://api.coindesk.com/v1/bpi/currentprice.json
			
			
			//Para el dollar
			
			let bpiObject:Dictionary = bitcoinObject[ViewController.kBPI2] as! Dictionary<String, Any>
			
			let usdObject:Dictionary = bpiObject[ViewController.kUSD] as! Dictionary<String, Any>
			self.rate = usdObject [ViewController.kRATE] as! Double
			
			
			//Lo mismo para el Euro
			
			let bitcoinObject2: Dictionary = bitcoinJSON as! Dictionary<String, Any>
			
			let bpiObject2:Dictionary = bitcoinObject2[ViewController.kBPI] as! Dictionary<String, Any>
			
			let eurObject:Dictionary = bpiObject2[ViewController.kEUR] as! Dictionary<String, Any>
			
			self.rate2 = eurObject [ViewController.kRATE2] as! Double
			
			
			//imprimo texto
			
			self.priceLabel.text = "\(self.rate) $"
			self.priceLabel2.text = "\(self.rate2) €"
			

            }
		
        }
    	@IBAction func recargaAction(_ sender: Any) {
        
		
            
    	priceLabel.text = "\(rate) $"
    	priceLabel2.text = "\(rate2) €"
    	}
}




